# Standard library imports
from datetime import datetime, timedelta
import csv
import io
import os
from zoneinfo import ZoneInfo

# Third-party imports
from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify, Response, current_app
from flask_login import login_required, current_user
import openpyxl
from openpyxl import load_workbook
from barcode import get_barcode_class
from barcode.writer import ImageWriter
from sqlalchemy import or_

# Local imports
from extensions import db
from models import Product, ProductBatch, ProductHistory, Requisition, RequisitionItem, Company, PendingRemoval, StockAudit
from helpers import user_redirect_to_requisition, admin_required, sys_admin_required, edit_delete_required, generate_barcode, generate_sub_barcode, log_activity, assign_company

# Create blueprint with URL prefix as required by project specifications
products = Blueprint('products', __name__, url_prefix='/products')


@products.route('/add_product', methods=['GET'])
@login_required
@user_redirect_to_requisition
@admin_required
def add_product_page():
    """Display the add product page"""
    # Get unique account titles for the current user's company
    if current_user.company_id:
        account_titles = db.session.query(Product.account_title).filter(
            Product.company_id == current_user.company_id
        ).distinct().order_by(Product.account_title).all()
    else:
        # For SYS-Admin with no company, get all account titles
        account_titles = db.session.query(Product.account_title).distinct().order_by(Product.account_title).all()
    
    account_titles = [title[0] for title in account_titles]
    
    # Create a minimal pagination object to prevent template errors
    from collections import namedtuple
    Pagination = namedtuple('Pagination', ['pages', 'total'])
    pagination = Pagination(pages=0, total=0)
    
    return render_template('products.html', account_titles=account_titles, pagination=pagination)


@products.route('/products', methods=['GET'])
@login_required
@user_redirect_to_requisition
@admin_required
def view_products():
    """Display the products page with filtering and pagination"""
    # Get query parameters
    page = request.args.get('page', 1, type=int)
    search_query = request.args.get('q', '').strip()
    account_type = request.args.get('account_type', '').strip()
    status_filter = request.args.get('status', '').strip()
    company_id = request.args.get('company_id', '').strip()
    
    # Base query - filter by current user's company
    if current_user.role == 'SYS-Admin' and current_user.company_id is None:
        # SYS-Admin with no company can see all products
        query = Product.query
        # For SYS-Admin, also get companies for the company filter
        companies = Company.query.all()
    else:
        # Filter by current user's company
        query = Product.query.filter_by(company_id=current_user.company_id)
        companies = None
    
    # Apply company filter for SYS-Admin
    if current_user.role == 'SYS-Admin' and company_id:
        try:
            company_id = int(company_id)
            query = query.filter_by(company_id=company_id)
        except (ValueError, TypeError):
            pass  # Invalid company_id, ignore filter
    
    # Apply search filter
    if search_query:
        search_filter = or_(
            Product.name.ilike(f'%{search_query}%'),
            Product.barcode.ilike(f'%{search_query}%'),
            Product.item_uom_desc.ilike(f'%{search_query}%')
        )
        query = query.filter(search_filter)
    
    # Apply account title filter
    if account_type:
        query = query.filter(Product.account_title == account_type)
    
    # Apply status filter
    if status_filter:
        if status_filter == 'OK':
            query = query.filter(Product.quantity > 0, ~Product.is_low_stock)
        elif status_filter == 'Low Stock':
            query = query.filter(Product.is_low_stock)
        elif status_filter == 'No Stock':
            query = query.filter(Product.quantity == 0)
        elif status_filter == 'Expiring Soon':
            # Products with batches expiring within 30 days
            today = datetime.now(ZoneInfo("Asia/Manila")).date()
            thirty_days = today + timedelta(days=30)
            query = query.join(ProductBatch).filter(
                ProductBatch.exp_date.between(today, thirty_days),
                ProductBatch.quantity > 0
            ).distinct()
        elif status_filter == 'Expiring 3 Months':
            # Products with batches expiring within 3 months (31-90 days)
            today = datetime.now(ZoneInfo("Asia/Manila")).date()
            thirty_days = today + timedelta(days=30)
            ninety_days = today + timedelta(days=90)
            query = query.join(ProductBatch).filter(
                ProductBatch.exp_date.between(thirty_days, ninety_days),
                ProductBatch.quantity > 0
            ).distinct()
        elif status_filter == 'Expired':
            # Products with expired batches
            today = datetime.now(ZoneInfo("Asia/Manila")).date()
            query = query.join(ProductBatch).filter(
                ProductBatch.exp_date < today,
                ProductBatch.quantity > 0
            ).distinct()
        elif status_filter == 'Favorites':
            query = query.filter(Product.is_favorite.is_(True))
    
    # Get unique account titles for the filter dropdown
    if current_user.company_id:
        account_titles = db.session.query(Product.account_title).filter(
            Product.company_id == current_user.company_id
        ).distinct().order_by(Product.account_title).all()
    else:
        # For SYS-Admin with no company, get all account titles
        account_titles = db.session.query(Product.account_title).distinct().order_by(Product.account_title).all()
    
    account_titles = [title[0] for title in account_titles]
    
    # Order by name and paginate
    query = query.order_by(Product.name)
    pagination = query.paginate(page=page, per_page=20, error_out=False)
    products = pagination.items
    
    # Pass query string for pagination links
    query_params = request.args.copy()
    if 'page' in query_params:
        del query_params['page']
    query_string = '&'.join([f"{key}={value}" for key, value in query_params.items()])
    
    return render_template('products.html', 
                         products=products,
                         pagination=pagination,
                         account_titles=account_titles,
                         query_string=query_string,
                         companies=companies,
                         now=datetime.now(ZoneInfo("Asia/Manila")))


@products.route('/add_product', methods=['POST'])
@login_required
@user_redirect_to_requisition
@admin_required
def add_product():
    """Add a new product"""
    try:
        # Debug: Print form data to see what's being received
        print("Form data received:")
        for key, value in request.form.items():
            print(f"  {key}: {value}")
        
        # Get form data
        name = request.form['name'].strip()
        account_title = request.form['account_title'].strip()
        item_uom_desc = request.form.get('item_uom_desc', '').strip()
        uom_conversion = request.form.get('uom_conversion', '1').strip()
        uom = request.form['uom'].strip()
        quantity = float(request.form.get('quantity', 0))
        # Use quantity as initial_quantity since that's what the form provides
        initial_quantity = quantity
        low_stock_threshold = int(request.form.get('low_stock_threshold', 
            current_app.config.get('LOW_STOCK_THRESHOLD_DEFAULT', 10)))
        reorder_level = int(request.form.get('reorder_level', 0))  # Get reorder level from form
        exp_date = request.form.get('exp_date', '').strip()
        purchase_order_place = request.form.get('purchase_order_place', '').strip()
        
        # Debug: Print parsed values
        print(f"Parsed values: name={name}, account_title={account_title}, uom={uom}, quantity={quantity}")
        
        # Validate required fields
        if not name or not account_title or not uom:
            flash('Name, Account Title, and UOM are required', 'error')
            print("Validation failed: Required fields missing")
            return redirect(url_for('products.view_products'))
        
        # UOM conversion should be treated as text, not converted to float
        # If empty, default to '1' as per project specification
        if not uom_conversion:
            uom_conversion = '1'
        
        # Generate unique barcode
        barcode = generate_barcode()
        print(f"Generated barcode: {barcode}")
        
        # Create new product with company assignment
        product = Product(
            barcode=barcode,
            name=name,
            account_title=account_title,
            item_uom_desc=item_uom_desc,
            uom_conversion=uom_conversion,  # Keep as string, don't convert to float
            uom=uom,
            quantity=quantity,
            initial_quantity=initial_quantity,
            low_stock_threshold=low_stock_threshold,
            reorder_level=reorder_level,  # Add reorder level to product
            exp_date=exp_date if exp_date else None,
            purchase_order_place=purchase_order_place
        )
        
        # Assign to current user's company
        product = assign_company(product)
        print(f"Assigned company: {product.company_id}")
        
        # Add to database
        db.session.add(product)
        db.session.flush()  # Flush to get the product ID
        print(f"Product added to session with ID: {product.id}")
        
        # Create ProductHistory record for TRANS IN (initial stock)
        if quantity > 0:
            current_time = datetime.now(ZoneInfo("Asia/Manila"))
            # Payee should include both product's purchase_order_place when available
            payee = purchase_order_place or 'Initial Stock'
            history_record = ProductHistory(
                product_id=product.id,
                trxn_date=current_time,
                trxn_code='TRANS IN',
                payee=payee,
                quantity_in=quantity,
                quantity_out=0.0,
                net_change=quantity,
                reference_id=None,  # No specific reference for initial stock
                reference_type='initial'
            )
            # Assign company to history record
            history_record = assign_company(history_record)
            db.session.add(history_record)
            print("ProductHistory record added")
        
        db.session.commit()
        print("Database commit successful")
        
        # If product has expiration date, create initial batch
        if exp_date:
            try:
                # Parse the expiration date
                exp_date_obj = datetime.strptime(exp_date, '%Y-%m-%d').date()
                
                # Create initial batch with sub-barcode
                batch = ProductBatch(
                    product_id=product.id,
                    quantity=quantity,
                    int_quantity=initial_quantity,
                    exp_date=exp_date_obj,
                    supplier_name=purchase_order_place if purchase_order_place else 'Initial Stock',
                    sub_barcode=generate_sub_barcode(barcode, exp_date_obj)  # Generate sub-barcode
                )
                db.session.add(batch)
                db.session.commit()
                
                flash(f'Product "{name}" added successfully with initial batch!', 'success')
                print(f'Product "{name}" added successfully with initial batch!')
            except ValueError as e:
                flash(f'Product "{name}" added, but failed to create initial batch due to invalid date format', 'warning')
                print(f"Batch creation failed: {e}")
                db.session.rollback()
        else:
            flash(f'Product "{name}" added successfully!', 'success')
            print(f'Product "{name}" added successfully!')
        
        # Log the activity
        log_activity(
            action="Product Added",
            details=f"Added product: {name} (Barcode: {barcode})"
        )
        print("Activity logged")
        
    except Exception as e:
        db.session.rollback()
        flash(f'Error adding product: {str(e)}', 'error')
        print(f"Exception occurred: {str(e)}")
        log_activity(
            action="Product Add Error",
            details=f"Failed to add product: {str(e)}"
        )
    
    return redirect(url_for('products.view_products'))


@products.route('/add_batch', methods=['POST'])
@login_required
@user_redirect_to_requisition
@admin_required
def add_batch():
    data = request.get_json()
    product_id = data.get('product_id')
    quantity = float(data.get('quantity'))
    exp_date_str = data.get('exp_date')
    supplier_name = data.get('supplier_name')  # Get supplier name from request

    if not all([product_id, quantity, exp_date_str]):
        return {'status': 'error', 'message': 'Missing required fields'}, 400

    try:
        exp_date = datetime.strptime(exp_date_str, '%Y-%m-%d').date()
        
        # Check if product exists and belongs to the user's company
        product = Product.query.filter_by(
            id=product_id,
            company_id=current_user.company_id
        ).first()

        if not product:
            return {'status': 'error', 'message': 'Product not found'}, 404

        # Create new batch with sub-barcode
        new_batch = ProductBatch(
            product_id=product_id,
            quantity=quantity,
            int_quantity=quantity,
            exp_date=exp_date,
            supplier_name=supplier_name,  # Add supplier name to batch
            sub_barcode=generate_sub_barcode(product.barcode, exp_date)  # Generate sub-barcode based on expiry date
        )

        db.session.add(new_batch)
        db.session.flush()  # Flush to get the batch ID

        # Create ProductHistory record for TRANS IN (batch addition)
        current_time = datetime.now(ZoneInfo("Asia/Manila"))
        # Payee should include both product's purchase_order_place and batch's supplier_name when available
        payee = format_payee_for_transaction(product, supplier_name)
        
        history_record = ProductHistory(
            product_id=product_id,
            trxn_date=current_time,
            trxn_code='TRANS IN',
            payee=payee,
            quantity_in=quantity,
            quantity_out=0.0,
            net_change=quantity,
            reference_id=new_batch.id,
            reference_type='batch',
            company_id=product.company_id
        )
        db.session.add(history_record)

        db.session.commit()

        log_activity(
            action="Add Batch",
            details=f"Added new batch to <strong>{product.name}</strong> with "
                    f"quantity <span class='badge bg-info'>{quantity} {product.uom}</span>, "
                    f"expires: <strong>{exp_date}</strong>, "
                    f"supplier: <strong>{supplier_name or 'N/A'}</strong>, "
                    f"sub-barcode: <strong>{new_batch.sub_barcode}</strong>"
        )

        return {'status': 'success', 'message': 'Batch added successfully'}

    except Exception as e:
        db.session.rollback()
        return {'status': 'error', 'message': str(e)}, 500


@products.route('/delete_batch', methods=['POST'])
@login_required
@user_redirect_to_requisition
@edit_delete_required
def delete_batch():
    data = request.get_json()
    product_id = data.get('product_id')
    batch_id = data.get('batch_id')

    if not all([product_id, batch_id]):
        return {'status': 'error', 'message': 'Missing required fields'}, 400

    # Convert to integers to ensure proper type matching
    try:
        product_id = int(product_id)
        batch_id = int(batch_id)
    except (ValueError, TypeError):
        return {'status': 'error', 'message': 'Invalid product_id or batch_id format'}, 400

    try:
        # Check if batch exists and belongs to the user's company
        batch = ProductBatch.query.join(Product).filter(
            ProductBatch.id == batch_id,
            ProductBatch.product_id == product_id
        ).filter(
            Product.company_id == current_user.company_id
        ).first()

        if not batch:
            return {'status': 'error', 'message': 'Batch not found'}, 404

        # Check if product exists and belongs to the user's company
        product = Product.query.filter_by(
            id=product_id,
            company_id=current_user.company_id
        ).first()

        if not product:
            return {'status': 'error', 'message': 'Product not found'}, 404

        # Check if batch is referenced in any pending removals (approved, rejected, or pending)
        pending_removals = PendingRemoval.query.filter_by(batch_id=batch_id).all()
        if pending_removals:
            # Remove the references to this batch in pending removals
            for removal in pending_removals:
                db.session.delete(removal)
            db.session.flush()  # Flush to remove the references

        # Update product quantity
        product.quantity -= batch.quantity
        if product.quantity < 0:
            product.quantity = 0

        # Delete the batch barcode image file before deleting the batch
        if batch.sub_barcode:
            try:
                # Determine the barcode image path
                if product.company_id:
                    barcode_image_path = os.path.join(current_app.root_path, 'static', 'batch_barcodes', f'company_{product.company_id}', f'{batch.sub_barcode}.png')
                else:
                    barcode_image_path = os.path.join(current_app.root_path, 'static', 'batch_barcodes', f'{batch.sub_barcode}.png')
                
                # Delete the barcode image file if it exists
                if os.path.exists(barcode_image_path):
                    os.remove(barcode_image_path)
            except Exception as e:
                # Log the error but don't stop the deletion process
                print(f"Warning: Could not delete barcode image for batch {batch.id}: {e}")

        # Log before deleting
        log_activity(
            action="Delete Batch",
            details=f"Deleted batch from <strong>{product.name}</strong> with "
                    f"quantity <span class='badge bg-info'>{batch.quantity} {product.uom}</span>, "
                    f"expiry: <strong>{batch.exp_date}</strong>"
        )

        db.session.delete(batch)
        db.session.commit()

        return {'status': 'success', 'message': 'Batch deleted successfully'}

    except Exception as e:
        db.session.rollback()
        return {'status': 'error', 'message': str(e)}, 500


def format_payee_for_transaction(product, supplier_name=None):
    """
    Format the payee field for a transaction based on product and supplier information.
    
    Args:
        product: Product object
        supplier_name: Supplier name string (optional)
        
    Returns:
        str: Formatted payee string
    """
    payee_parts = []
    if product.purchase_order_place:
        payee_parts.append(product.purchase_order_place)
    if supplier_name:
        payee_parts.append(supplier_name)
    
    # If neither is available, use a default value
    return " - ".join(payee_parts) if payee_parts else 'Manual Addition'


@products.route('/update_batch', methods=['POST'])
@login_required
@user_redirect_to_requisition
@edit_delete_required
def update_batch():
    """Update batch metadata like expiration date and supplier name (Admin only)."""
    data = request.get_json() or {}
    product_id = data.get('product_id')
    batch_id = data.get('batch_id')
    exp_date_str = data.get('exp_date')  # may be None/'' for supplies
    supplier_name = data.get('supplier_name')
    new_quantity_str = data.get('quantity')

    if not all([product_id, batch_id]):
        return jsonify({'status': 'error', 'message': 'Missing required fields'}), 400

    # Normalize types
    try:
        product_id = int(product_id)
        batch_id = int(batch_id)
    except (ValueError, TypeError):
        return jsonify({'status': 'error', 'message': 'Invalid product_id or batch_id format'}), 400

    try:
        # Check if product exists and belongs to the user's company
        product = Product.query.filter_by(
            id=product_id,
            company_id=current_user.company_id
        ).first()
        
        if not product:
            return jsonify({'status': 'error', 'message': 'Product not found'}), 404

        # Check if batch exists and belongs to the user's company
        batch = ProductBatch.query.join(Product).filter(
            ProductBatch.id == batch_id,
            ProductBatch.product_id == product_id
        ).filter(
            Product.company_id == current_user.company_id
        ).first()
        
        if not batch:
            return jsonify({'status': 'error', 'message': 'Batch not found for this product'}), 404

        # Determine if product is supplies (non-expiring allowed)
        supplies_categories = ['Supplies-Kitchen', 'Supplies-Packaging', 'Supplies-Store Dining', 'Supplies-Store Office', 'Supplies-Utility']
        is_supplies_product = product.account_title in supplies_categories or product.account_title.lower().startswith('supplies')

        # Parse/validate new expiration date
        new_exp_date = None
        if exp_date_str:
            try:
                new_exp_date = datetime.strptime(exp_date_str, '%Y-%m-%d').date()
            except ValueError:
                return jsonify({'status': 'error', 'message': 'Invalid date format. Use YYYY-MM-DD'}), 400
        else:
            # Allow blank for supplies (set to far-future)
            if is_supplies_product:
                new_exp_date = datetime(2099, 12, 31).date()
            else:
                return jsonify({'status': 'error', 'message': 'Expiry date is required for non-Supplies products'}), 400

        # Keep old values for logging
        old_exp_date = batch.exp_date
        old_supplier = batch.supplier_name
        old_quantity = batch.quantity

        # Apply updates
        batch.exp_date = new_exp_date
        batch.supplier_name = supplier_name
        
        # If quantity provided, validate and update
        if new_quantity_str is not None and new_quantity_str != '':
            try:
                new_quantity = float(new_quantity_str)
            except ValueError:
                return jsonify({'status': 'error', 'message': 'Invalid quantity format'}), 400
            if new_quantity < 0:
                return jsonify({'status': 'error', 'message': 'Quantity must be non-negative'}), 400
            batch.quantity = new_quantity

        # Recalculate product total quantity from all batches to ensure consistency
        all_batches = ProductBatch.query.filter_by(product_id=product_id).all()
        product.quantity = sum(b.quantity for b in all_batches)
        product.initial_quantity = product.quantity
        product.last_updated = datetime.now(ZoneInfo("Asia/Manila"))

        # If supplier name changed, update the payee field in ProductHistory records
        if old_supplier != supplier_name:
            # Find all ProductHistory records that reference this batch
            history_records = ProductHistory.query.filter_by(
                reference_id=batch_id,
                reference_type='batch'
            ).all()
            
            # Update the payee field for each record
            for record in history_records:
                # Update the payee to reflect the new supplier name
                record.payee = format_payee_for_transaction(product, supplier_name)
        
        db.session.commit()

        # Log changes
        log_activity(
            action="Update Batch",
            details=(
                f"Updated batch for <strong>{product.name}</strong><br>"
                f"Supplier: <strong>{old_supplier or '-'} ➜ {supplier_name or '-'}</strong><br>"
                f"Expiry: <strong>{old_exp_date.strftime('%Y-%m-%d') if old_exp_date else '-'} ➜ {new_exp_date.strftime('%Y-%m-%d') if new_exp_date else '-'}</strong><br>"
                f"Quantity: <strong>{old_quantity} ➜ {batch.quantity}</strong>"
            )
        )

        return jsonify({'status': 'success', 'message': 'Batch updated successfully'})

    except Exception as e:
        db.session.rollback()
        return jsonify({'status': 'error', 'message': str(e)}), 500


@products.route('/add_stock', methods=['POST'])
@login_required
@user_redirect_to_requisition
@admin_required
def add_stock():
    product_id = request.form['product_id']
    add_qty = float(request.form['quantity'])
    supplier_name = request.form.get('supplier_name')
    exp_date_str = request.form.get('exp_date')

    # Get current time in PHT
    current_time = datetime.now(ZoneInfo("Asia/Manila"))

    exp_date = None
    if exp_date_str:
        exp_date = datetime.strptime(exp_date_str, '%Y-%m-%d')

    # Check if product exists and belongs to the user's company
    product = Product.query.filter_by(
        id=product_id,
        company_id=current_user.company_id
    ).first()
    
    if not product:
        return jsonify({'message': 'Product not found'}), 404

    # Check if this is a Supplies product
    supplies_categories = ['Supplies-Kitchen', 'Supplies-Packaging', 'Supplies-Store Dining', 'Supplies-Store Office', 'Supplies-Utility']
    is_supplies_product = product.account_title in supplies_categories or product.account_title.lower().startswith('supplies')

    # Create new batch
    if exp_date:
        # For products with expiry date
        new_batch = ProductBatch(
            product_id=product_id,
            quantity=add_qty,
            int_quantity=add_qty,
            exp_date=exp_date.date(),
            supplier_name=supplier_name,
            added_on=current_time,
            sub_barcode=generate_sub_barcode(product.barcode, exp_date.date())  # Generate sub-barcode
        )
    elif is_supplies_product:
        # For Supplies products without expiry date, use a far-future date
        future_date = datetime(2099, 12, 31).date()
        new_batch = ProductBatch(
            product_id=product_id,
            quantity=add_qty,
            int_quantity=add_qty,
            exp_date=future_date,
            supplier_name=supplier_name,
            added_on=current_time,
            sub_barcode=generate_sub_barcode(product.barcode, future_date)  # Generate sub-barcode
        )
    else:
        # For non-Supplies products without expiry date, return error
        return jsonify({'message': 'Expiry date is required for non-Supplies products'}), 400

    # sub_barcode is now generated above, so we don't need to generate it here
    # new_batch.sub_barcode = generate_sub_barcode(product.barcode, new_batch.exp_date)
    
    db.session.add(new_batch)
    db.session.flush()  # Flush to get the batch ID

    # Now recalculate product quantity from all batches to ensure consistency
    all_batches = ProductBatch.query.filter_by(product_id=product_id).all()
    total_batch_quantity = sum(batch.quantity for batch in all_batches)

    # Update product quantity to match the sum of all batch quantities
    product.quantity = total_batch_quantity
    product.initial_quantity = total_batch_quantity 
    product.last_updated = current_time

    # Create ProductHistory record for TRANS IN (manual addition)
    # Payee should include both product's purchase_order_place and batch's supplier_name when available
    payee = format_payee_for_transaction(product, supplier_name)
    
    history_record = ProductHistory(
        product_id=product_id,
        trxn_date=current_time,
        trxn_code='TRANS IN',
        payee=payee,
        quantity_in=add_qty,
        quantity_out=0.0,
        net_change=add_qty,
        reference_id=new_batch.id,
        reference_type='batch',
        company_id=product.company_id
    )
    db.session.add(history_record)

    db.session.commit()

    # Format the time for logging
    formatted_time = current_time.strftime('%Y-%m-%d %I:%M:%S %p')

    # Determine expiry date for logging
    if exp_date:
        exp_date_str = exp_date.strftime('%Y-%m-%d')
    elif is_supplies_product:
        exp_date_str = 'N/A (Supplies)'
    else:
        exp_date_str = 'N/A'

    log_activity(
        action="Add Stock",
        details=f"<strong>{add_qty} {product.uom}</strong> added to "
                f"<strong>{product.name}</strong><br>"
                f"Batch exp: {exp_date_str}<br>"
                f"Supplier: {supplier_name or 'N/A'}<br>"
                f"Added on: {formatted_time}<br>"
                f"New Total: <span class='badge bg-warning'>{product.quantity} {product.uom}</span>"
    )

    return '', 200


@products.route('/remove_stock', methods=['POST'])
@login_required
@user_redirect_to_requisition
@edit_delete_required
def remove_stock():
    product_id = request.form['product_id']
    batch_id = request.form['batch_id']
    remove_qty = float(request.form['quantity'])
    reason = request.form['reason']
    remarks = request.form.get('remarks', '')

    # Get current time in PHT
    current_time = datetime.now(ZoneInfo("Asia/Manila"))

    # Check if batch exists and belongs to the user's company
    batch = ProductBatch.query.join(Product).filter(
        ProductBatch.id == batch_id,
        ProductBatch.product_id == product_id
    ).filter(
        Product.company_id == current_user.company_id
    ).first()
    
    if not batch:
        return "Invalid batch selected", 400

    # Check if product exists and belongs to the user's company
    product = Product.query.filter_by(
        id=product_id,
        company_id=current_user.company_id
    ).first()
    
    if not product:
        return "Product not found", 404

    if batch.quantity < remove_qty:
        return f"Error: Not enough stock in selected batch. Available: {batch.quantity}", 400

    # Update batch quantity
    batch.quantity = batch.quantity - remove_qty

    # Create ProductHistory record for TRANS OUT (manual removal)
    history_record = ProductHistory(
        product_id=product_id,
        trxn_date=current_time,
        trxn_code='TRANS OUT',
        payee=f'Manual Removal - {reason}',
        quantity_in=0.0,
        quantity_out=remove_qty,
        net_change=-remove_qty,
        reference_id=batch.id,
        reference_type='batch'
    )
    # Assign company_id to the history record
    history_record = assign_company(history_record)
    db.session.add(history_record)

    # Update product total quantity
    product.quantity = product.quantity - remove_qty
    product.last_updated = current_time
    db.session.commit()

    # Format the time for logging
    formatted_time = current_time.strftime('%Y-%m-%d %I:%M:%S %p')

    # Log activity with detailed information
    log_activity(
        action="Remove Stock",
        details=(f"<strong>{remove_qty} {product.uom}</strong> removed from "
                f"<strong>{product.name}</strong><br>"
                f"Batch #{batch.id} (Exp: {batch.exp_date.strftime('%Y-%m-%d')})<br>"
                f"Removed on: {formatted_time}<br>"
                f"Reason: {reason}<br>"
                f"Remarks: {remarks}<br>"
                f"Remaining in batch: {batch.quantity} {product.uom}<br>"
                f"Total remaining: <span class='badge bg-warning'>{product.quantity} {product.uom}</span>")
    )

    return '', 200


@products.route('/lookup_product/<barcode>')
def lookup_product(barcode):
    # For SYS-Admin users, allow access to all products regardless of company
    if current_user.role == 'SYS-Admin':
        product = Product.query.filter_by(barcode=barcode).first()
    else:
        # For other users, check only in their company
        product = Product.query.filter_by(
            barcode=barcode,
            company_id=current_user.company_id
        ).first()

    if product:
        return jsonify({
            'success': True,
            'id': product.id,
            'name': product.name,
            'quantity': product.quantity,
            'account_title': product.account_title,
            'uom': product.uom,
            'barcode': product.barcode,
            'initial_quantity': product.initial_quantity,
            'low_stock_threshold': product.low_stock_threshold,
            'company_id': product.company_id,
            'reorder_level': product.reorder_level,  # Add reorder_level to the response
            'is_low_stock': product.is_low_stock  # Add is_low_stock property to the response
        })
    else:
        # Check if product exists in another company (for non-SYS-Admin users)
        if current_user.role != 'SYS-Admin':
            product = Product.query.filter_by(barcode=barcode).first()
            if product:
                # Product exists but not in the user's company
                user_company_id = getattr(current_user, 'company_id', None)
                product_company_id = getattr(product, 'company_id', None)
                
                # If user has a company but product doesn't belong to that company, show error
                if user_company_id and product_company_id and user_company_id != product_company_id:
                    try:
                        company_name = product.company.name if product.company else "Unknown Company"
                    except:
                        company_name = "Unknown Company"
                    return jsonify({
                        'success': False, 
                        'message': f'Access denied. This product belongs to {company_name}, not your company.'
                    })
                
                # If user doesn't have a company but product does, show error
                if not user_company_id and product_company_id:
                    try:
                        company_name = product.company.name if product.company else "Unknown Company"
                    except:
                        company_name = "Unknown Company"
                    return jsonify({
                        'success': False, 
                        'message': f'Access denied. This product belongs to {company_name}, not your company.'
                    })
                
                # If product doesn't have a company but user does, show error
                if user_company_id and not product_company_id:
                    return jsonify({
                        'success': False, 
                        'message': 'Access denied. This product does not belong to any company, while you have a company assigned.'
                    })
        
        return jsonify({'success': False, 'message': 'Product not found'})


@products.route('/get_product_batches/<int:product_id>')
def get_product_batches(product_id):
    # Check if product exists and belongs to the user's company
    product = Product.query.filter_by(
        id=product_id,
        company_id=current_user.company_id
    ).first_or_404()

    # Get all batches ordered by expiration date
    batches = (ProductBatch.query
               .filter_by(product_id=product_id)
               .order_by(ProductBatch.exp_date)
               .all())

    # Calculate total quantity
    total_quantity = sum(batch.quantity for batch in batches)

    # Format batch data
    batch_data = []
    current_date = datetime.now(ZoneInfo("Asia/Manila")).date()

    for index, batch in enumerate(batches, start=1):
        # Calculate days until expiry
        days_until_expiry = (batch.exp_date - current_date).days
        expiry_status = (
            'text-danger' if days_until_expiry <= 30 else
            'text-warning' if days_until_expiry <= 60 else
            'text-success'
        )

        batch_data.append({
            'id': batch.id,
            'batch_number': index,
            'quantity': batch.quantity,
            'exp_date': batch.exp_date.strftime('%Y-%m-%d'),
            'added_on': batch.added_on.strftime('%Y-%m-%d %I:%M:%S %p'),
            'days_until_expiry': days_until_expiry,
            'expiry_status': expiry_status,
            'percentage': 0,
            'sub_barcode': batch.sub_barcode  # Add sub-barcode to the response
        })

    return jsonify({
        'success': True,
        'product_name': product.name,
        'product_uom': product.uom,
        'total_quantity': total_quantity,
        'batches': batch_data
    })


@products.route('/toggle_favorite/<int:product_id>', methods=['POST'])
@login_required
@user_redirect_to_requisition
@admin_required
def toggle_product_favorite(product_id):
    """Toggle favorite status for a product"""
    try:
        # Check if product exists and belongs to the user's company
        product = Product.query.filter_by(
            id=product_id,
            company_id=current_user.company_id
        ).first_or_404()
        
        # Toggle the favorite status
        product.is_favorite = not product.is_favorite
        db.session.commit()
        
        action = "added to" if product.is_favorite else "removed from"
        
        return jsonify({
            'success': True,
            'is_favorite': product.is_favorite,
            'message': f'Product {action} favorites successfully.'
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': f'Error toggling favorite: {str(e)}'
        }), 500


@products.route('/export_inventory_xlsx')
@login_required
@user_redirect_to_requisition
def export_inventory_xlsx():
    """Export inventory data as Excel (.xlsx) file."""
    try:
        # Define account codes dictionary
        account_codes = {
          "COS-Beverages": 201, "COS-Ice Cream": 202, "COS-Desserts": 203, "COS-Food": 204,
          "COS-Chicken": 205, "COS-Condiments": 206, "COS-Rice": 207,
          "Supplies-Kitchen": 300, "Supplies-Packaging": 301, "Supplies-Store Dining": 302,
          "Supplies-Store Office": 303, "Supplies-Utility": 304
        }
        
        # Base query - filter by current user's company
        if current_user.role == 'SYS-Admin' and current_user.company_id is None:
            # SYS-Admin with no company can see all products
            query = Product.query
        else:
            # Filter by current user's company
            query = Product.query.filter_by(company_id=current_user.company_id)
        
        # Get relevant products (COS-Beverages to Supplies-Utility)
        relevant_categories = [
            "COS-Beverages", "COS-Ice Cream", "COS-Desserts", "COS-Food",
            "COS-Chicken", "COS-Condiments", "COS-Rice",
            "Supplies-Kitchen", "Supplies-Packaging", "Supplies-Store Dining",
            "Supplies-Store Office", "Supplies-Utility"
        ]
        
        # Query products in these categories and current user's company
        products_list = query.filter(
            Product.account_title.in_(relevant_categories)
        ).order_by(Product.account_title, Product.name).all()
        
        # Create Excel workbook
        from openpyxl import Workbook
        from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
        from openpyxl.utils import get_column_letter
        
        wb = Workbook()
        ws = wb.active
        ws.title = "Inventory Report"
        
        # Define styles
        header_font = Font(bold=True, color="FFFFFF")
        header_fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
        header_alignment = Alignment(horizontal="center", vertical="center")
        
        # Define borders
        thin_border = Border(
            left=Side(style='thin'),
            right=Side(style='thin'),
            top=Side(style='thin'),
            bottom=Side(style='thin')
        )
        
        # Write header row
        headers = [
            'Product Name', 'Description', 'UOM', 'Account Title', 'FS Code', 
            'Purchase Order Place', 'Current Stock', 'Stock Status', 'Nearest Expiry Date'
        ]
        
        for col, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col, value=header)
            cell.font = header_font
            cell.fill = header_fill
            cell.alignment = header_alignment
            cell.border = thin_border
        
        # Write data rows
        now_ph = datetime.now(ZoneInfo("Asia/Manila"))
        row = 2
        
        for product in products_list:
            # Calculate stock status using the is_low_stock property
            if product.quantity == 0:
                stock_status = "Out of Stock"
            elif product.is_low_stock:
                stock_status = "Low Stock"
            else:
                stock_status = "In Stock"
            
            # Get nearest expiry date
            nearest_expiry = None
            if product.batches:
                # Get batches with stock and future expiry dates
                valid_batches = [batch for batch in product.batches if batch.quantity > 0 and batch.exp_date > now_ph.date()]
                if valid_batches:
                    nearest_batch = min(valid_batches, key=lambda x: x.exp_date)
                    nearest_expiry = nearest_batch.exp_date.strftime('%Y-%m-%d')
                else:
                    # Check for expired batches
                    expired_batches = [batch for batch in product.batches if batch.quantity > 0 and batch.exp_date <= now_ph.date()]
                    if expired_batches:
                        nearest_expiry = "EXPIRED"
            
            # Write row data
            row_data = [
                product.name,
                product.item_uom_desc or '',
                product.uom or '',
                product.account_title,
                account_codes.get(product.account_title, ''),
                product.purchase_order_place or '',
                product.quantity,
                stock_status,
                nearest_expiry or 'N/A'
            ]
            
            for col, value in enumerate(row_data, 1):
                cell = ws.cell(row=row, column=col, value=value)
                cell.border = thin_border
                
                # Apply conditional formatting for stock status
                if col == 8:  # Stock Status column
                    if value == "Out of Stock":
                        cell.fill = PatternFill(start_color="FF0000", end_color="FF0000", fill_type="solid")
                        cell.font = Font(color="FFFFFF", bold=True)
                    elif value == "Low Stock":
                        cell.fill = PatternFill(start_color="FFA500", end_color="FFA500", fill_type="solid")
                        cell.font = Font(color="FFFFFF", bold=True)
                    elif value == "In Stock":
                        cell.fill = PatternFill(start_color="90EE90", end_color="90EE90", fill_type="solid")
                        cell.font = Font(color="000000", bold=True)
            
            row += 1
        
        # Auto-adjust column widths
        for column in ws.columns:
            max_length = 0
            column_letter = get_column_letter(column[0].column)
            
            for cell in column:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(str(cell.value))
                except:
                    pass
            
            adjusted_width = min(max_length + 2, 50)  # Cap at 50 characters
            ws.column_dimensions[column_letter].width = adjusted_width
        
        # Save to bytes
        output = io.BytesIO()
        wb.save(output)
        output.seek(0)
        
        # Prepare response
        timestamp = datetime.now(ZoneInfo("Asia/Manila")).strftime('%Y%m%d_%H%M%S')
        
        return Response(
            output.getvalue(),
            mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": f"attachment;filename=inventory_export_{timestamp}.xlsx"}
        )
        
    except Exception as e:
        # Log the error
        log_activity(
            action="Export Excel Error",
            details=f"Failed to export Excel: {str(e)}"
        )
        flash(f'Error exporting Excel: {str(e)}', 'error')
        return redirect(url_for('products.view_products'))


@products.route('/import_products_csv', methods=['GET', 'POST'])
@login_required
@user_redirect_to_requisition
@admin_required
def import_products_csv():
    """Import products from CSV file"""
    if request.method == 'GET':
        return render_template('import_products.html')
    
    if 'csv_file' not in request.files:
        flash('No file selected', 'error')
        return redirect(request.url)
    
    file = request.files['csv_file']
    if file.filename == '':
        flash('No file selected', 'error')
        return redirect(request.url)
    
    if not (file.filename.endswith('.csv') or file.filename.endswith('.xlsx')):
        flash('Please upload a CSV or Excel (.xlsx) file', 'error')
        return redirect(request.url)
    
    try:
        # Read file content based on file type
        if file.filename.endswith('.csv'):
            # Handle CSV file
            csv_content = file.read().decode('utf-8')
            csv_reader = csv.DictReader(io.StringIO(csv_content))
        elif file.filename.endswith('.xlsx'):
            # Handle Excel file
            file.seek(0)  # Reset file pointer
            workbook = load_workbook(file, data_only=True)
            sheet = workbook.active
            
            # Get headers from first row
            headers = [cell.value for cell in sheet[1] if cell.value]
            
            # Create reader-like object for Excel
            class ExcelReader:
                def __init__(self, sheet, headers):
                    self.sheet = sheet
                    self.headers = headers
                    self.current_row = 2  # Start from second row (after headers)
                
                def __iter__(self):
                    return self
                
                def __next__(self):
                    if self.current_row > self.sheet.max_row:
                        raise StopIteration
                    
                    row_data = {}
                    for col, header in enumerate(self.headers, 1):
                        cell_value = self.sheet.cell(row=self.current_row, column=col).value
                        row_data[header] = str(cell_value) if cell_value is not None else ''
                    
                    self.current_row += 1
                    return row_data
            
            csv_reader = ExcelReader(sheet, headers)
        
        imported_count = 0
        skipped_count = 0
        errors = []
        
        for row_num, row in enumerate(csv_reader, start=2):  # Start from 2 because row 1 is header
            try:
                # Validate required fields
                required_fields = ['name', 'account_title', 'uom']
                for field in required_fields:
                    if not row.get(field) or row[field].strip() == '':
                        errors.append(f"Row {row_num}: Missing required field '{field}'")
                        continue
                
                # Check if product already exists (by name and account_title)
                existing_product = Product.query.filter_by(
                    name=row['name'].strip(),
                    account_title=row['account_title'].strip()
                ).first()
                
                if existing_product:
                    errors.append(f"Row {row_num}: Product '{row['name']}' already exists")
                    skipped_count += 1
                    continue
                
                # Generate unique barcode
                barcode = generate_barcode()
                
                # Parse quantity (optional, defaults to 0)
                quantity = 0.0  # default to 0 if not provided
                if row.get('quantity') and row['quantity'].strip():
                    try:
                        quantity = float(row['quantity'])
                        if quantity < 0:
                            errors.append(f"Row {row_num}: Quantity must be non-negative")
                            continue
                    except ValueError:
                        errors.append(f"Row {row_num}: Invalid quantity format")
                        continue
                
                # Parse low stock threshold
                low_stock_threshold = 10  # default
                if row.get('low_stock_threshold'):
                    try:
                        low_stock_threshold = int(row['low_stock_threshold'])
                        if low_stock_threshold < 0 or low_stock_threshold > 100:
                            errors.append(f"Row {row_num}: Low stock threshold must be between 0-100")
                            continue
                    except ValueError:
                        errors.append(f"Row {row_num}: Invalid low stock threshold format")
                        continue
                    
                # Parse reorder level (optional, defaults to 0)
                reorder_level = 0  # default
                if row.get('reorder_level'):
                    try:
                        reorder_level = int(row['reorder_level'])
                        if reorder_level < 0:
                            errors.append(f"Row {row_num}: Reorder level must be non-negative")
                            continue
                    except ValueError:
                        errors.append(f"Row {row_num}: Invalid reorder level format")
                        continue
                
                # Parse expiration date
                exp_date = None
                if row.get('exp_date') and row['exp_date'].strip():
                    try:
                        exp_date = datetime.strptime(row['exp_date'].strip(), '%Y-%m-%d').date()
                    except ValueError:
                        errors.append(f"Row {row_num}: Invalid date format. Use YYYY-MM-DD")
                        continue
                
                # For supplies categories, if no expiry given, treat as non-expiring
                supplies_categories = ['Supplies-Kitchen', 'Supplies-Packaging', 'Supplies-Store Dining', 'Supplies-Store Office', 'Supplies-Utility']
                if not exp_date and (row['account_title'] in supplies_categories or row['account_title'].lower().startswith('supplies')):
                    exp_date = datetime(2099, 12, 31).date()
                
                # Create new product
                new_product = Product(
                    barcode=barcode,
                    name=row['name'].strip(),
                    quantity=quantity,
                    initial_quantity=quantity,
                    low_stock_threshold=low_stock_threshold,
                    reorder_level=reorder_level,  # Add reorder level to product
                    account_title=row['account_title'].strip(),
                    item_uom_desc=row.get('item_uom_desc', '').strip(),
                    uom_conversion=row.get('uom_conversion', '1'),
                    uom=row['uom'].strip(),
                    purchase_order_place=row.get('purchase_order_place', '').strip(),
                    exp_date=row.get('exp_date', '')
                )
                
                # Assign to current user's company
                new_product = assign_company(new_product)
                
                db.session.add(new_product)
                db.session.flush()  # so we can use new_product.id
                
                # Create batch if expiration date is provided AND there's stock
                if exp_date and quantity > 0:
                    first_batch = ProductBatch(
                        product_id=new_product.id,
                        quantity=quantity,
                        int_quantity=quantity,
                        exp_date=exp_date,
                        supplier_name=row.get('supplier_name', '').strip(),
                        sub_barcode=generate_sub_barcode(new_product.barcode, exp_date)  # Generate sub-barcode
                    )
                    db.session.add(first_batch)
                
                imported_count += 1
                
            except Exception as e:
                errors.append(f"Row {row_num}: {str(e)}")
                # Rollback the session to clear any failed transaction
                db.session.rollback()
                continue
        
        # Commit all successful imports
        if imported_count > 0:
            db.session.commit()
            
            log_activity(
                action="Import Products from CSV",
                details=f"Successfully imported <strong>{imported_count}</strong> products from CSV file. "
                        f"Skipped: {skipped_count} products."
            )
            
            flash(f'Successfully imported {imported_count} products. Skipped {skipped_count} products.', 'success')
        else:
            db.session.rollback()
            flash('No products were imported. Please check the CSV format and data.', 'error')
        
        # Show errors if any
        if errors:
            error_message = f"Import completed with {len(errors)} errors:\n" + "\n".join(errors[:10])  # Show first 10 errors
            if len(errors) > 10:
                error_message += f"\n... and {len(errors) - 10} more errors"
            flash(error_message, 'warning')
        
        return redirect(url_for('products.view_products'))
        
    except Exception as e:
        db.session.rollback()
        flash(f'Error importing CSV: {str(e)}', 'error')
        # Log the full error for debugging
        import traceback
        print(f"Import error: {traceback.format_exc()}")
        return redirect(request.url)


@products.route('/import_from_product_dict', methods=['POST'])
@login_required
@user_redirect_to_requisition
@admin_required
def import_from_product_dict():
    """Import products from the product_dict.csv file in the root directory"""
    csv_file_path = os.path.join(current_app.root_path, 'product_dict.csv')
    
    if not os.path.exists(csv_file_path):
        flash('product_dict.csv file not found in the application root directory', 'error')
        return redirect(url_for('products.view_products'))
    
    try:
        with open(csv_file_path, 'r', encoding='utf-8') as file:
            csv_reader = csv.DictReader(file)
            
            imported_count = 0
            skipped_count = 0
            errors = []
            
            for row_num, row in enumerate(csv_reader, start=2):  # Start from 2 because row 1 is header
                try:
                    # Validate required fields
                    required_fields = ['name', 'account_title', 'uom']
                    for field in required_fields:
                        if not row.get(field) or row[field].strip() == '':
                            errors.append(f"Row {row_num}: Missing required field '{field}'")
                            continue
                    
                    # Check if product already exists (by name and account_title)
                    existing_product = Product.query.filter_by(
                        name=row['name'].strip(),
                        account_title=row['account_title'].strip()
                    ).first()
                    
                    if existing_product:
                        errors.append(f"Row {row_num}: Product '{row['name']}' already exists")
                        skipped_count += 1
                        continue
                    
                    # Generate unique barcode
                    barcode = generate_barcode()
                    
                    # Parse quantity (optional, defaults to 0)
                    quantity = 0.0  # default to 0 if not provided
                    if row.get('quantity') and row['quantity'].strip():
                        try:
                            quantity = float(row['quantity'])
                            if quantity < 0:
                                errors.append(f"Row {row_num}: Quantity must be non-negative")
                                continue
                        except ValueError:
                            errors.append(f"Row {row_num}: Invalid quantity format")
                            continue
                    
                    # Parse low stock threshold
                    low_stock_threshold = 10  # default
                    if row.get('low_stock_threshold'):
                        try:
                            low_stock_threshold = int(row['low_stock_threshold'])
                            if low_stock_threshold < 0 or low_stock_threshold > 100:
                                errors.append(f"Row {row_num}: Low stock threshold must be between 0-100")
                                continue
                        except ValueError:
                            errors.append(f"Row {row_num}: Invalid low stock threshold format")
                            continue
                    
                    # Parse expiration date
                    exp_date = None
                    if row.get('exp_date') and row['exp_date'].strip():
                        try:
                            exp_date = datetime.strptime(row['exp_date'].strip(), '%Y-%m-%d').date()
                        except ValueError:
                            errors.append(f"Row {row_num}: Invalid date format. Use YYYY-MM-DD")
                            continue
                    
                    # For supplies categories, if no expiry given, treat as non-expiring
                    supplies_categories = ['Supplies-Kitchen', 'Supplies-Packaging', 'Supplies-Store Dining', 'Supplies-Store Office', 'Supplies-Utility']
                    if not exp_date and (row['account_title'] in supplies_categories or row['account_title'].lower().startswith('supplies')):
                        exp_date = datetime(2099, 12, 31).date()
                    
                    # Create new product
                    new_product = Product(
                        barcode=barcode,
                        name=row['name'].strip(),
                        quantity=quantity,
                        initial_quantity=quantity,
                        low_stock_threshold=low_stock_threshold,
                        account_title=row['account_title'].strip(),
                        item_uom_desc=row.get('item_uom_desc', '').strip(),
                        uom_conversion=row.get('uom_conversion', '1'),
                        uom=row['uom'].strip(),
                        purchase_order_place=row.get('purchase_order_place', '').strip(),
                        exp_date=row.get('exp_date', '')
                    )
                    
                    # Assign to current user's company
                    new_product = assign_company(new_product)
                    
                    db.session.add(new_product)
                    db.session.flush()  # so we can use new_product.id
                    
                    # Create batch if expiration date is provided AND there's stock
                    if exp_date and quantity > 0:
                        first_batch = ProductBatch(
                            product_id=new_product.id,
                            quantity=quantity,
                            int_quantity=quantity,
                            exp_date=exp_date,
                            supplier_name=row.get('supplier_name', '').strip(),
                            sub_barcode=generate_sub_barcode(new_product.barcode, exp_date)  # Generate sub-barcode
                        )
                        db.session.add(first_batch)
                    
                    imported_count += 1
                    
                except Exception as e:
                    errors.append(f"Row {row_num}: {str(e)}")
                    # Rollback the session to clear any failed transaction
                    db.session.rollback()
                    continue
            
            # Commit all successful imports
            if imported_count > 0:
                db.session.commit()
                
                log_activity(
                    action="Import Products from product_dict.csv",
                    details=f"Successfully imported <strong>{imported_count}</strong> products from product_dict.csv. "
                            f"Skipped: {skipped_count} products."
                )
                
                flash(f'Successfully imported {imported_count} products from product_dict.csv. Skipped {skipped_count} products.', 'success')
            else:
                db.session.rollback()
                flash('No products were imported. Please check the CSV format and data.', 'error')
            
            # Show errors if any
            if errors:
                error_message = f"Import completed with {len(errors)} errors:\n" + "\n".join(errors[:10])  # Show first 10 errors
                if len(errors) > 10:
                    error_message += f"\n... and {len(errors) - 10} more errors"
                flash(error_message, 'warning')
            
            return redirect(url_for('products.view_products'))
            
    except Exception as e:
        db.session.rollback()
        flash(f'Error importing from product_dict.csv: {str(e)}', 'error')
        return redirect(url_for('products.view_products'))


@products.route('/product_history/<int:product_id>')
@login_required
@user_redirect_to_requisition
def product_history(product_id):
    """Display transaction history for a specific product"""
    # Check if product exists and belongs to the user's company
    if current_user.role == 'SYS-Admin':
        # SYS-Admin can access any product
        product = Product.query.get_or_404(product_id)
    else:
        # Other users must belong to the same company
        product = Product.query.filter_by(
            id=product_id,
            company_id=current_user.company_id
        ).first_or_404()
    
    # Get all history records for this product, ordered by transaction date (newest first)
    history_records = ProductHistory.query.filter_by(product_id=product_id)\
        .order_by(ProductHistory.trxn_date.desc())\
        .all()
    
    return render_template('product_history.html', 
                         product=product, 
                         history_records=history_records)


@products.route('/delete_product/<int:product_id>', methods=['POST'])
@login_required
@edit_delete_required
def delete_product(product_id):
    """Delete a product and all its batches, history, and related records"""
    try:
        # Check if product exists and belongs to the user's company
        product = Product.query.filter_by(
            id=product_id,
            company_id=current_user.company_id
        ).first()
        
        if not product:
            flash('Product not found or access denied', 'error')
            return redirect(url_for('products.view_products'))
        
        # Get all related records before deleting the product
        # Check if product has any pending removals (approved, rejected, or pending)
        pending_removals = PendingRemoval.query.filter_by(product_id=product_id).all()
        
        # Get all batches for this product
        batches = ProductBatch.query.filter_by(product_id=product_id).all()
        
        # Get all history records for this product
        history_records = ProductHistory.query.filter_by(product_id=product_id).all()
        
        # Get all requisition items for this product
        requisition_items = RequisitionItem.query.filter_by(product_id=product_id).all()
        
        # Get all stock audits for this product
        stock_audits = StockAudit.query.filter_by(product_id=product_id).all()
        
        # Start deleting related records
        # Delete all pending removals
        for removal in pending_removals:
            db.session.delete(removal)
        
        # Delete all stock audits
        for audit in stock_audits:
            db.session.delete(audit)
        
        # Delete all batches
        for batch in batches:
            db.session.delete(batch)
        
        # Delete all history records
        for history in history_records:
            db.session.delete(history)
        
        # Delete all requisition items
        for item in requisition_items:
            db.session.delete(item)
        
        # Log the deletion
        log_activity(
            action="Delete Product",
            details=f"Deleted product <strong>{product.name}</strong> (Barcode: {product.barcode}) "
                    f"with {len(batches)} batches, {len(history_records)} history records, "
                    f"{len(requisition_items)} requisition items, {len(stock_audits)} stock audits, "
                    f"and {len(pending_removals)} pending removals"
        )
        
        # Delete the product itself
        db.session.delete(product)
        db.session.commit()
        
        flash(f'Product "{product.name}" deleted successfully', 'success')
        
    except Exception as e:
        db.session.rollback()
        flash(f'Error deleting product: {str(e)}', 'error')
    
    # Preserve search parameters when redirecting
    # Get the referrer URL to maintain search parameters
    referrer = request.referrer
    if referrer and '/products/products' in referrer:
        # If coming from the products page, redirect back to it with parameters
        return redirect(referrer)
    else:
        # Fallback to default products view
        return redirect(url_for('products.view_products'))
