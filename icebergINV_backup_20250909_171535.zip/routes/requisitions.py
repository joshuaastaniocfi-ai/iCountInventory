# Standard library imports
import json
from datetime import datetime
from zoneinfo import ZoneInfo

# Third-party imports
from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify, current_app
from flask_login import login_required, current_user
from flask_mail import Message

# Local imports
from extensions import db, mail
from models import Product, Requisition, RequisitionItem, RequisitionBatchDeduction, User, ProductHistory, Company
from helpers import user_redirect_to_requisition, admin_required, sys_admin_required, log_activity, assign_company

# Create blueprint with URL prefix as required by project specifications
requisitions = Blueprint('requisitions', __name__, url_prefix='/requisitions')


@requisitions.route('/requisition_form', methods=['GET'])
@login_required
def requisition_form():
    # Only allow User role to access requisition form
    if current_user.role not in ['User']:
        flash('Access denied. Only regular users can submit requisitions.', 'error')
        return redirect(url_for('main.dashboard'))
    
    # Check for flash messages from login
    login_success = request.args.get('login_success', 'false')
    
    # Filter products by company for the user
    products = Product.query.filter_by(company_id=current_user.company_id).all()
    now = datetime.utcnow()
    return render_template('requisition_form.html', products=products, now=now, login_success=login_success)


@requisitions.route('/submit_requisition', methods=['POST'])
@login_required
def submit_requisition():
    # Only allow User role to submit requisitions
    if current_user.role not in ['User']:
        return jsonify({'success': False, 'message': 'Access denied. Only regular users can submit requisitions.'}), 403
    
    requested_by = request.form['requested_by']
    contact_number = request.form.get('contact_number')
    # Use company franchise name or company name instead of user branch
    if current_user.company:
        branch = current_user.company.franchise_name if current_user.company.franchise_name else current_user.company.name
    else:
        branch = request.form['branch']  # Fallback to form value if no company
    
    items = json.loads(request.form['items_json'])

    requisition = Requisition(requested_by=requested_by, status='Pending',
                            contact_number=contact_number, branch=branch)
    
    # Assign to current user's company
    requisition = assign_company(requisition)
    
    db.session.add(requisition)
    db.session.flush()

    for item in items:
        ri = RequisitionItem(
            requisition_id=requisition.id,
            product_id=item['product_id'],
            quantity=float(item['quantity']),
            uom=item['uom']
        )
        db.session.add(ri)

    db.session.commit()
    
    # Send email receipt to the user
    try:
        # Get user's email from the current user
        user_email = current_user.email
        
        # Prepare email content
        subject = f"Requisition Receipt - #{requisition.id} - Status: Pending"
        
        # Build items list for email
        items_html = ""
        total_items = 0
        for item in items:
            items_html += f"""
            <tr>
                <td>{item['product_name']}</td>
                <td>{item['quantity']} {item['uom']}</td>
            </tr>
            """
            total_items += 1
        
        # Create HTML email body
        html_body = f"""
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; text-align: center; border-radius: 10px 10px 0 0;">
                <h1 style="margin: 0; font-size: 24px;">New Requisition Submitted</h1>
                <p style="margin: 10px 0 0 0; opacity: 0.9;">#{requisition.id} - Pending Approval</p>
            </div>
            
            <div style="padding: 20px; background: #f8f9fa; border-radius: 0 0 10px 10px;">
                <h2 style="color: #333; border-bottom: 2px solid #667eea; padding-bottom: 10px;">Requisition Details</h2>
                
                <div style="margin: 15px 0;">
                    <p><strong>Requisition ID:</strong> #{requisition.id}</p>
                    <p><strong>Requested By:</strong> {requisition.requested_by}</p>
                    <p><strong>Contact Number:</strong> {requisition.contact_number or 'N/A'}</p>
                    <p><strong>Franchise Name:</strong> {requisition.branch}</p>
                    <p><strong>Status:</strong> <span style="background: #ffc107; color: #000; padding: 3px 8px; border-radius: 12px; font-weight: bold;">{requisition.status}</span></p>
                    <p><strong>Date Submitted:</strong> {requisition.date_created.strftime('%Y-%m-%d %H:%M:%S')}</p>
                </div>
                
                <h3 style="color: #333; border-bottom: 1px solid #ddd; padding-bottom: 8px;">Items Requested ({total_items} items)</h3>
                <table style="width: 100%; border-collapse: collapse; margin: 15px 0;">
                    <thead>
                        <tr style="background: #e9ecef;">
                            <th style="padding: 10px; text-align: left; border: 1px solid #ddd;">Product</th>
                            <th style="padding: 10px; text-align: left; border: 1px solid #ddd;">Quantity</th>
                        </tr>
                    </thead>
                    <tbody>
                        {items_html}
                    </tbody>
                </table>
                
                <div style="background: #e3f2fd; padding: 15px; border-radius: 5px; margin: 20px 0;">
                    <p style="margin: 0; color: #1976d2;">
                        <strong>ℹ️ Next Steps:</strong> Your requisition is now pending approval. 
                        You will receive another email once it has been processed.
                    </p>
                </div>
                
                <p style="color: #666; font-size: 14px; margin-top: 20px; border-top: 1px solid #dee2e6; padding-top: 20px;">
                    <strong>⚠️ No Reply:</strong> This is an automated message. Please do not reply to this email.
                </p>
            </div>
            <div style="background-color: #e9ecef; padding: 15px; text-align: center; color: #666; font-size: 12px;">
                © 2025 iCount Inventory System. All rights reserved.
            </div>
        </div>
        """
        
        msg = Message(
            subject=subject,
            recipients=[user_email],
            html=html_body
        )
        mail.send(msg)
        
    except Exception as e:
        # Log the error but don't fail the requisition submission
        print(f"Failed to send email: {str(e)}")
    
    # Log the activity
    log_activity(
        action="Requisition Submitted",
        details=f"Requisition #{requisition.id} submitted by {current_user.full_name}"
    )
    
    return jsonify({'success': True, 'message': 'Requisition submitted successfully!', 'requisition_id': requisition.id})


@requisitions.route('/view_requisitions')
@login_required
@user_redirect_to_requisition
def view_requisitions():
    """Display all requisitions with pagination and filters"""
    page = request.args.get('page', 1, type=int)
    status = request.args.get('status', '').strip()
    search = request.args.get('q', '').strip()
    per_page = current_app.config.get('REQUISITIONS_PER_PAGE', 10)
    
    # Base query - modified to allow SYS-Admin to see all requisitions
    if current_user.role == 'User':
        # Regular users can only see their own requisitions
        query = Requisition.query.filter_by(
            requested_by=current_user.full_name,
            company_id=current_user.company_id
        )
    elif current_user.role == 'SYS-Admin':
        # SYS-Admin can see all requisitions across all companies
        query = Requisition.query
    else:
        # Other admins (WH-Admin, Company-Admin) can see all requisitions in their company
        query = Requisition.query.filter_by(company_id=current_user.company_id)
    
    # Apply status filter if provided
    if status:
        query = query.filter_by(status=status)
    
    # Apply search filter if provided
    if search:
        like = f"%{search}%"
        query = query.filter(db.or_(
            Requisition.requested_by.ilike(like),
            Requisition.branch.ilike(like)  # This now contains franchise name
        ))
    
    # Order by date created (newest first)
    query = query.order_by(Requisition.date_created.desc())
    
    # Paginate results
    pagination = query.paginate(
        page=page, 
        per_page=per_page, 
        error_out=False
    )
    
    requisitions = pagination.items
    
    # Get Philippines time using zoneinfo
    ph_time = datetime.now(ZoneInfo("Asia/Manila"))
    
    # Prepare current filters for pagination
    current_filters = {}
    if status:
        current_filters['status'] = status
    if search:
        current_filters['q'] = search
    
    return render_template(
        'requisitions.html', 
        requisitions=requisitions, 
        pagination=pagination,
        status=status,
        search=search,
        now=ph_time,
        current_filters=current_filters
    )


@requisitions.route('/update_status/<int:requisition_id>', methods=['POST'])
@login_required
@user_redirect_to_requisition
def update_status(requisition_id):
    new_status = request.form['status']
    requisition = Requisition.query.get_or_404(requisition_id)

    # If trying to approve and requisition is not validated, prevent approval
    if new_status == 'approved' and not requisition.validated:
        flash(f'Error: Requisition #{requisition.id} must be validated through scanning before approval.', 'error')
        return redirect(url_for('requisitions.view_requisitions'))

    # Handle stock deduction only if approving and currently pending
    if requisition.status == 'Pending' and new_status == 'approved':
        # Get delivery date and time from form if provided
        date_of_delivery_str = request.form.get('date_of_delivery')
        time_of_delivery_str = request.form.get('time_of_delivery')
        date_of_delivery = None
        
        if date_of_delivery_str and time_of_delivery_str:
            try:
                from datetime import datetime
                # Combine date and time strings and parse as datetime
                datetime_str = f"{date_of_delivery_str} {time_of_delivery_str}"
                date_of_delivery = datetime.strptime(datetime_str, '%Y-%m-%d %H:%M')
            except ValueError:
                flash('Invalid delivery date or time format.', 'error')
                return redirect(url_for('requisitions.view_requisitions'))
        elif date_of_delivery_str:
            # If only date is provided, use midnight as default time
            try:
                from datetime import datetime
                date_of_delivery = datetime.strptime(date_of_delivery_str, '%Y-%m-%d')
            except ValueError:
                flash('Invalid delivery date format.', 'error')
                return redirect(url_for('requisitions.view_requisitions'))

        for req_item in requisition.items:
            product = req_item.product
            remaining_quantity = req_item.quantity  # How much we still need to deduct

            if product.quantity < req_item.quantity:
                flash(f'Error: Not enough stock for {product.name}. Requested: {req_item.quantity}, Available: {product.quantity}', 'error')
                return redirect(url_for('requisitions.view_requisitions'))

            # Store the total current quantity before any deduction
            total_before_deduction = product.quantity

            # Get all batches sorted by expiration date (first)
            batches = sorted(product.batches, key=lambda x: x.exp_date)

            # Track which batches were updated for logging
            updated_batches = []

            # Deduct from batches starting with expiry
            for batch in batches:
                if remaining_quantity <= 0:
                    break

                if batch.quantity > 0:  # Only use batches that have stock
                    deduct_amount = min(batch.quantity, remaining_quantity)
                    batch.quantity = batch.quantity - deduct_amount
                    remaining_quantity -= deduct_amount
                    updated_batches.append({
                        'batch_id': batch.id,
                        'exp_date': batch.exp_date.strftime('%Y-%m-%d'),
                        'deducted': deduct_amount,
                        'remaining': batch.quantity
                    })

            # Update total product quantity
            product.quantity = product.quantity - req_item.quantity

            # Store deduction summary (not per-batch details)
            db.session.add(
                RequisitionBatchDeduction(
                    requisition_item_id=req_item.id,
                    total_current_qty=total_before_deduction,
                    requested_qty=req_item.quantity,
                    remaining_qty=product.quantity
                )
            )

            # Create ProductHistory record for TRANS OUT
            history_record = ProductHistory(
                product_id=req_item.product_id,
                trxn_date=datetime.now(ZoneInfo("Asia/Manila")),
                trxn_code='TRANS OUT',
                payee=requisition.branch or 'Unknown',  # branch now contains franchise name
                quantity_in=0.0,
                quantity_out=req_item.quantity,
                net_change=-req_item.quantity,
                reference_id=requisition.id,
                reference_type='requisition'
            )
            # Assign company_id from the requisition to the history record
            history_record.company_id = requisition.company_id
            db.session.add(history_record)

        # Set approval date and delivery date/time
        requisition.date_approved = datetime.now(ZoneInfo("Asia/Manila"))
        requisition.date_of_delivery = date_of_delivery

    # Update the status
    requisition.status = new_status
    db.session.commit()
    
    # Show flash message based on status
    if new_status == 'approved':
        flash(f'Requisition #{requisition.id} has been approved successfully!', 'success')
    else:
        flash(f'Requisition #{requisition.id} has been {new_status}.', 'warning')

    # Send email notification to the requester about status update
    try:
        # Find the user who submitted the requisition
        # Since we only have the name, we'll try to find by name and company
        user = User.query.join(Company).filter(
            User.full_name == requisition.requested_by,
            Company.name == requisition.branch  # branch now contains franchise name
        ).first()
        
        if user and user.email:
            # Prepare email content based on status
            if new_status == 'approved':
                subject = f"Requisition #{requisition.id} - APPROVED!"
                body = f"""
Dear {requisition.requested_by},

Great news! Your requisition has been APPROVED.

REQUISITION DETAILS:
Requisition ID: #{requisition.id}
Date Submitted: {requisition.date_created.strftime('%B %d, %Y at %I:%M %p')}
Franchise Name: {requisition.branch}
Status: APPROVED
Approved On: {datetime.now(ZoneInfo("Asia/Manila")).strftime('%B %d, %Y at %I:%M %p')}

Expect a call or email from our team regarding delivery/pickup arrangements.

If you have any questions, please contact your administrator.

Thank you for using our inventory system.

Best regards,
iCount Inventory System
                """
            else:
                # Status is declined
                subject = f"Requisition #{requisition.id} - Status Update"
                body = f"""
Dear {requisition.requested_by},

Your requisition status has been updated.

REQUISITION DETAILS:
Requisition ID: #{requisition.id}
Date Submitted: {requisition.date_created.strftime('%B %d, %Y at %I:%M %p')}
Franchise Name: {requisition.branch}
Status: {new_status.title()}
Updated On: {datetime.now(ZoneInfo("Asia/Manila")).strftime('%B %d, %Y at %I:%M %p')}

REQUESTED ITEMS:
"""
                # Add items list
                for req_item in requisition.items:
                    body += f"• {req_item.product.name} - {req_item.quantity} {req_item.uom}\n"
                
                body += f"""

If you have any questions about this decision, please contact your administrator.

Thank you for using our inventory system.

Best regards,
iCount Inventory System
                """
            
            # Create and send email
            msg = Message(
                subject=subject,
                recipients=[user.email],
                body=body.strip(),
                sender=current_app.config['MAIL_DEFAULT_SENDER']
            )
            
            mail.send(msg)
            
    except Exception as e:
        # Log the error but don't fail the status update
        print(f"Failed to send status update email: {str(e)}")
        # You might want to log this error properly in production

    # Determine action label for logging
    action_label = "Approved" if new_status == "approved" else "Declined"

    # Log activity (clean and scalable format)
    log_activity(
        action=f"{action_label} Requisition",
        details=(
            f"Requisition <strong>#{requisition.id}</strong> by <strong>{requisition.requested_by}</strong> "
            f"was <strong>{action_label.lower()}</strong> with <strong>{len(requisition.items)} item(s)</strong>."
        )
    )

    return redirect(url_for('requisitions.view_requisitions'))


@requisitions.route('/print_delivery_form/<int:requisition_id>')
@login_required
@user_redirect_to_requisition
def print_delivery_form(requisition_id):
    requisition = Requisition.query.get_or_404(requisition_id)

    if requisition.status != 'approved':
        return "Only approved requisitions can be printed.", 403

    return render_template('print_form.html', requisition=requisition)


@requisitions.route('/delete_requisition/<int:requisition_id>', methods=['POST'])
@login_required
@sys_admin_required
def delete_requisition(requisition_id):
    """Delete an approved requisition"""
    requisition = Requisition.query.get_or_404(requisition_id)
    
    # Only allow deletion of approved or rejected requisitions
    if requisition.status not in ['approved', 'rejected']:
        return jsonify({
            'success': False, 
            'message': 'Only approved or rejected requisitions can be deleted.'
        }), 400
    
    try:
        # Remove activity logging
        # log_activity(
        #     action="Deleted Requisition",
        #     details=(
        #         f"Requisition <strong>#{requisition.id}</strong> by <strong>{requisition.requested_by}</strong> "
        #         f"was <strong>deleted</strong> by admin <strong>{current_user.full_name}</strong>."
        #     )
        # )

        # Delete the requisition (cascade will handle related items)
        db.session.delete(requisition)
        db.session.commit()

        # Add flash message for normal form POSTs
        if request.accept_mimetypes.accept_html and not request.is_json:
            flash('Requisition deleted successfully.', 'success')
            return redirect(url_for('requisitions.view_requisitions'))

        return jsonify({
            'success': True,
            'message': 'Requisition deleted successfully.'
        })
        
    except Exception as e:
        db.session.rollback()
        print(f"Error deleting requisition: {str(e)}")
        return jsonify({
            'success': False,
            'message': 'An error occurred while deleting the requisition.'
        }), 500