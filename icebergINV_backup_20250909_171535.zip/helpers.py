# Standard library imports
import barcode
from barcode.writer import ImageWriter
from datetime import datetime, timedelta
from functools import wraps
from zoneinfo import ZoneInfo
import os

# Third-party imports
from flask import redirect, url_for, flash, current_app
from flask_login import current_user

# Local imports
from extensions import db
from models import User, Product, ActivityLog, ProductBatch


def is_mobile_device(user_agent):
    """Check if the user agent indicates a mobile device"""
    if not user_agent:
        return False
    
    user_agent_lower = user_agent.lower()
    mobile_keywords = [
        'mobile', 'android', 'iphone', 'ipad', 'blackberry', 
        'windows phone', 'opera mini', 'mobile safari', 'mobile chrome'
    ]
    
    is_mobile = any(keyword in user_agent_lower for keyword in mobile_keywords)
    
    return is_mobile


def get_redirect_url_for_user(user, user_agent):
    """Determine the appropriate redirect URL based on user role and device type"""
    is_mobile = is_mobile_device(user_agent)
    
    if user.role == 'User':
        return url_for('requisitions.requisition_form', login_success='true')
    elif user.role in ['SYS-Admin', 'WH-Admin', 'Company-Admin']:
        if is_mobile:
            return url_for('scanner.mobile_scanner')
        else:
            return url_for('main.dashboard')
    else:
        return url_for('main.dashboard')


def user_redirect_to_requisition(view_func):
    """Decorator to redirect User role to requisition form"""
    @wraps(view_func)
    def decorated_view(*args, **kwargs):
        if current_user.is_authenticated and current_user.role == 'User':
            return redirect(url_for('requisitions.requisition_form'))
        return view_func(*args, **kwargs)
    return decorated_view


def admin_required(view_func):
    """Decorator to require admin privileges"""
    @wraps(view_func)
    def decorated_view(*args, **kwargs):
        if not current_user.is_authenticated:
            return redirect(url_for('auth.login'))
        if getattr(current_user, 'role', None) not in ['SYS-Admin', 'WH-Admin', 'Company-Admin']:
            flash('Access denied. SYS-Admin, WH-Admin, or Company-Admin privileges required.', 'error')
            return redirect(url_for('main.dashboard'))
        return view_func(*args, **kwargs)
    return decorated_view


def sys_admin_required(view_func):
    """Decorator to require SYS-Admin privileges only"""
    @wraps(view_func)
    def decorated_view(*args, **kwargs):
        if not current_user.is_authenticated:
            return redirect(url_for('auth.login'))
        if getattr(current_user, 'role', None) != 'SYS-Admin':
            flash('Access denied. SYS-Admin privileges required.', 'error')
            return redirect(url_for('main.dashboard'))
        return view_func(*args, **kwargs)
    return decorated_view


def edit_delete_required(view_func):
    """Decorator to require SYS-Admin or Company-Admin privileges for edit/delete operations (excludes WH-Admin)"""
    @wraps(view_func)
    def decorated_view(*args, **kwargs):
        if not current_user.is_authenticated:
            return redirect(url_for('auth.login'))
        if getattr(current_user, 'role', None) not in ['SYS-Admin', 'Company-Admin']:
            flash('Access denied. SYS-Admin or Company-Admin privileges required for this operation.', 'error')
            return redirect(url_for('main.dashboard'))
        return view_func(*args, **kwargs)
    return decorated_view


def generate_barcode():
    """Generate a unique barcode for new products"""
    import os
    import time
    import traceback
    
    base = current_app.config.get('BARCODE_BASE', "12082016")
    
    # Get the highest existing barcode number to ensure uniqueness
    existing_products = Product.query.all()
    max_number = 0
    
    for product in existing_products:
        try:
            # Extract the numeric part from existing barcodes
            if product.barcode and product.barcode.startswith(base):
                number_part = product.barcode[len(base):]
                if number_part.isdigit():
                    max_number = max(max_number, int(number_part))
        except (ValueError, AttributeError):
            continue
    
    # Generate next unique number
    next_number = max_number + 1
    code = base + str(next_number).zfill(4)
    
    # Create company-specific path to static/product_barcodes directory (updated path)
    if hasattr(current_user, 'company_id') and current_user.company_id:
        static_dir = os.path.join(current_app.root_path, 'static', 'product_barcodes', f'company_{current_user.company_id}')
    else:
        static_dir = os.path.join(current_app.root_path, 'static', 'product_barcodes')
    
    # Ensure the directory exists
    try:
        os.makedirs(static_dir, exist_ok=True)
    except Exception as e:
        print(f"Warning: Could not create barcode directory {static_dir}: {e}")
        # Fallback to default directory
        static_dir = os.path.join(current_app.root_path, 'static', 'product_barcodes')
        os.makedirs(static_dir, exist_ok=True)
    
    # Create full filename path
    filename = os.path.join(static_dir, code)
    
    try:
        ean = barcode.get('ean13', code, writer=ImageWriter())
        ean.save(filename)
    except Exception as e:
        # Log the error but still return the barcode code
        print(f"Warning: Could not generate barcode image for {code}: {e}")
        print(f"Full traceback: {traceback.format_exc()}")
    
    return code


def generate_sub_barcode(product_barcode, exp_date, db_connection=None, company_id=None):
    """Generate a unique sub-barcode for a batch based on the expiry date"""
    import os
    import time
    from datetime import datetime
    import traceback
    
    # Format expiry date as YYYYMMDD (8 digits) instead of MMDDYYYY
    exp_date_str = exp_date.strftime("%Y%m%d")
    
    # Use expiry date as base (8 digits)
    base = exp_date_str
    
    # Get the highest existing sub-barcode number for this expiry date
    max_number = 0
    
    # Look through all batches with sub-barcodes that start with our base
    if db_connection:
        # Direct database connection (no Flask context)
        cursor = db_connection.cursor()
        cursor.execute('SELECT sub_barcode FROM product_batch WHERE sub_barcode LIKE ?', (f"{base}%",))
        batches = cursor.fetchall()
        
        for (sub_barcode,) in batches:
            try:
                # Extract the numeric part from existing sub-barcodes (last 4 digits)
                if sub_barcode and len(sub_barcode) >= 12:
                    number_part = sub_barcode[-4:]  # Last 4 digits
                    if number_part.isdigit():
                        max_number = max(max_number, int(number_part))
            except (ValueError, AttributeError):
                continue
    else:
        # Flask context (original implementation)
        batches = ProductBatch.query.filter(ProductBatch.sub_barcode.like(f"{base}%")).all()
        
        for batch in batches:
            try:
                # Extract the numeric part from existing sub-barcodes (last 4 digits)
                if batch.sub_barcode and len(batch.sub_barcode) >= 12:
                    number_part = batch.sub_barcode[-4:]  # Last 4 digits
                    if number_part.isdigit():
                        max_number = max(max_number, int(number_part))
            except (ValueError, AttributeError):
                continue
    
    # Generate next unique number (4 digits)
    next_number = max_number + 1
    
    # Create sub-barcode with base + 4-digit sequence (12 characters total)
    sub_barcode = f"{base}{str(next_number).zfill(4)}"
    
    # Generate the actual barcode image if we're in Flask context
    if not db_connection:
        try:
            # Create company-specific path to static/batch_barcodes directory
            if company_id:
                static_dir = os.path.join(current_app.root_path, 'static', 'batch_barcodes', f'company_{company_id}')
            elif hasattr(current_user, 'company_id') and current_user.company_id:
                static_dir = os.path.join(current_app.root_path, 'static', 'batch_barcodes', f'company_{current_user.company_id}')
            else:
                static_dir = os.path.join(current_app.root_path, 'static', 'batch_barcodes')
            
            # Ensure the directory exists
            os.makedirs(static_dir, exist_ok=True)
            
            # Generate the barcode image (13th character will be checksum)
            EAN = barcode.get_barcode_class('ean13')
            ean = EAN(sub_barcode, writer=ImageWriter())
            filename = os.path.join(static_dir, sub_barcode)
            ean.save(filename)
        except Exception as e:
            # If there's an error generating the image, we still return the barcode
            print(f"Warning: Could not generate barcode image for sub-barcode {sub_barcode}: {e}")
            print(f"Full traceback: {traceback.format_exc()}")
    
    # Return only the 12-character barcode (without checksum)
    return sub_barcode


def log_activity(action, details=None):
    """Log an activity to the database"""
    # Get current time in PHT
    current_time = datetime.now(ZoneInfo("Asia/Manila"))
    log = ActivityLog(
        action=action,
        details=details,
        timestamp=current_time
    )
    
    # Assign company if user is logged in and has a company
    if hasattr(current_user, 'is_authenticated') and current_user.is_authenticated:
        if hasattr(current_user, 'company_id') and current_user.company_id:
            log.company_id = current_user.company_id
    
    db.session.add(log)
    db.session.commit()


def assign_company(record):
    """Assign current user's company to a new record"""
    if hasattr(current_user, 'company_id') and current_user.company_id:
        record.company_id = current_user.company_id
    return record


def get_company_upload_directory(company_id, directory_type='uploads'):
    """Get company-specific directory path for uploads or reports"""
    if directory_type == 'uploads':
        return os.path.join(current_app.root_path, 'uploads', f'company_{company_id}')
    elif directory_type == 'reports':
        return os.path.join(current_app.root_path, 'reports', f'company_{company_id}')
    else:
        raise ValueError("directory_type must be 'uploads' or 'reports'")