# Standard library imports
from datetime import datetime
from zoneinfo import ZoneInfo


# Third-party imports
from flask_login import UserMixin
from werkzeug.security import check_password_hash, generate_password_hash
import secrets

# Local imports
from extensions import db


class Company(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), unique=True, nullable=False)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(ZoneInfo("Asia/Manila")))
    franchise_name = db.Column(db.String(150), nullable=True)
    logo = db.Column(db.String(200), nullable=True)

    # Relationships
    users = db.relationship('User', backref='company')
    products = db.relationship('Product', backref='company')
    requisitions = db.relationship('Requisition', backref='company')
    stock_audits = db.relationship('StockAudit', backref='company')
    product_histories = db.relationship('ProductHistory', backref='company')
    pending_removals = db.relationship('PendingRemoval', backref='company')


class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    full_name = db.Column(db.String(150), nullable=False)
    username = db.Column(db.String(100), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    branch = db.Column(db.String(100))
    password_hash = db.Column(db.String(200), nullable=False)
    role = db.Column(db.String(50), default='User')
    email_verified = db.Column(db.Boolean, default=False)
    verification_token = db.Column(db.String(100), unique=True)
    company_id = db.Column(db.Integer, db.ForeignKey('company.id'), nullable=True)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    # Treat unverified users as inactive so Flask-Login refuses to log them in
    @property
    def is_active(self):  # type: ignore[override]
        return bool(self.email_verified)

    def generate_verification_token(self):
        self.verification_token = secrets.token_urlsafe(32)
        return self.verification_token


class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    barcode = db.Column(db.String(20), unique=True, nullable=False)
    name = db.Column(db.String(100), nullable=False)
    account_title = db.Column(db.String(100), nullable=False)
    item_uom_desc = db.Column(db.String(200))
    uom_conversion = db.Column(db.String(100))
    uom = db.Column(db.String(50))
    quantity = db.Column(db.Float, nullable=False, default=0.0)
    initial_quantity = db.Column(db.Float, nullable=False, default=0.0)
    low_stock_threshold = db.Column(db.Integer, default=10)
    reorder_level = db.Column(db.Integer, default=0)  # Added reorder_level column
    exp_date = db.Column(db.String(50))  # kept for backward compatibility
    purchase_order_place = db.Column(db.String(100))
    last_updated = db.Column(db.DateTime, default=lambda: datetime.now(ZoneInfo("Asia/Manila")))
    is_favorite = db.Column(db.Boolean, default=False)
    company_id = db.Column(db.Integer, db.ForeignKey('company.id'), nullable=False)

    @property
    def is_low_stock(self):
        # Check if reorder_level is set and use it for low stock determination
        if self.reorder_level > 0:
            return self.quantity <= self.reorder_level
        # Fallback to threshold-based calculation if no reorder_level is set
        if self.initial_quantity == 0:
            return False
        threshold_qty = self.initial_quantity * (self.low_stock_threshold / 100)
        return self.quantity <= threshold_qty


class ProductBatch(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'), nullable=False)
    quantity = db.Column(db.Float, nullable=False, default=0.0)
    int_quantity = db.Column(db.Float, nullable=False, default=0.0)
    exp_date = db.Column(db.Date, nullable=False)
    supplier_name = db.Column(db.String(100), nullable=True)
    added_on = db.Column(db.DateTime, default=lambda: datetime.now(ZoneInfo("Asia/Manila")))
    # Add sub-barcode field
    sub_barcode = db.Column(db.String(30), unique=True, nullable=False)  # Unique sub-barcode for each batch
    product = db.relationship('Product', backref='batches')
    # Note: Inherits company_id through product relationship


class Requisition(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    date_created = db.Column(db.DateTime, default=lambda: datetime.now(ZoneInfo("Asia/Manila")))
    requested_by = db.Column(db.String(100), nullable=False)
    status = db.Column(db.String(20), default='Pending')
    contact_number = db.Column(db.String(20))
    branch = db.Column(db.String(50))
    company_id = db.Column(db.Integer, db.ForeignKey('company.id'), nullable=False)
    items = db.relationship('RequisitionItem', backref='requisition', cascade="all, delete-orphan")
    # Add validated field to track if requisition has been validated through scanning
    validated = db.Column(db.Boolean, default=False, nullable=False)
    # Add date fields for approval and delivery
    date_approved = db.Column(db.DateTime, nullable=True)
    date_of_delivery = db.Column(db.DateTime, nullable=True)
    # Note: RequisitionItem and RequisitionBatchDeduction inherit company context through relationships


class RequisitionItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    requisition_id = db.Column(db.Integer, db.ForeignKey('requisition.id'), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'), nullable=False)
    quantity = db.Column(db.Float, nullable=False, default=0.0)
    uom = db.Column(db.String(50), nullable=False)
    product = db.relationship('Product')
    deductions = db.relationship('RequisitionBatchDeduction', backref='requisition_item', cascade="all, delete-orphan")
    # Note: Inherits company_id through requisition relationship


class RequisitionBatchDeduction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    requisition_item_id = db.Column(db.Integer, db.ForeignKey('requisition_item.id'), nullable=False)
    total_current_qty = db.Column(db.Float, nullable=False, default=0.0)  # Total quantity from all batches before deduction
    requested_qty = db.Column(db.Float, nullable=False, default=0.0)      # Amount requested
    remaining_qty = db.Column(db.Float, nullable=False, default=0.0)      # Amount left after deduction
    # Note: Inherits company_id through requisition_item -> requisition relationship


class ActivityLog(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    action = db.Column(db.String(200), nullable=False)
    details = db.Column(db.Text)
    timestamp = db.Column(db.DateTime, default=lambda: datetime.now(ZoneInfo("Asia/Manila")))
    company_id = db.Column(db.Integer, db.ForeignKey('company.id'), nullable=True)


class StockAudit(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'), nullable=False)
    recorded_quantity = db.Column(db.Float, nullable=False, default=0.0)
    actual_quantity = db.Column(db.Float, nullable=False, default=0.0)
    discrepancy = db.Column(db.Float, nullable=False, default=0.0)
    verified_by = db.Column(db.String(100), nullable=False)
    timestamp = db.Column(db.DateTime, default=lambda: datetime.now(ZoneInfo("Asia/Manila")))
    batch_label = db.Column(db.String(100), nullable=False)
    is_settled = db.Column(db.Boolean, default=False)
    company_id = db.Column(db.Integer, db.ForeignKey('company.id'), nullable=False)
    product = db.relationship('Product', backref='audits')


# BatchAudit model for the batch_audit table
class BatchAudit(db.Model):
    __tablename__ = 'batch_audit'
    
    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer, nullable=False)
    product_name = db.Column(db.String(100), nullable=False)
    product_uom = db.Column(db.String(50))
    batch_id = db.Column(db.Integer, nullable=False)
    batch_barcode = db.Column(db.String(100), nullable=False)
    exp_date = db.Column(db.Date)
    recorded_quantity = db.Column(db.Float, nullable=False)
    actual_quantity = db.Column(db.Float, nullable=False)
    discrepancy = db.Column(db.Float, nullable=False)
    verified_by = db.Column(db.String(100), nullable=False)
    audit_timestamp = db.Column(db.DateTime, default=lambda: datetime.now(ZoneInfo("Asia/Manila")))
    status = db.Column(db.String(20), default='pending')
    is_settled = db.Column(db.Boolean, default=False)
    batch_label = db.Column(db.String(100))  # Added batch_label field for grouping
    company_id = db.Column(db.Integer, db.ForeignKey('company.id'), nullable=True)  # Added company_id field


class ProductHistory(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'), nullable=False)
    trxn_date = db.Column(db.DateTime, nullable=False)
    trxn_code = db.Column(db.String(20), nullable=False)  # 'TRANS IN' or 'TRANS OUT'
    payee = db.Column(db.String(200), nullable=False)  # purchase_order_place for TRANS IN, branch for TRANS OUT
    quantity_in = db.Column(db.Float, default=0.0)  # Quantity added
    quantity_out = db.Column(db.Float, default=0.0)  # Quantity removed
    net_change = db.Column(db.Float, nullable=False, default=0.0)  # Positive for TRANS IN, negative for TRANS OUT
    reference_id = db.Column(db.Integer)  # ID of the related batch or requisition
    reference_type = db.Column(db.String(50))  # 'batch' or 'requisition'
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(ZoneInfo("Asia/Manila")))
    company_id = db.Column(db.Integer, db.ForeignKey('company.id'), nullable=False)
    
    product = db.relationship('Product', backref='history')


class PendingRemoval(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'), nullable=False)
    batch_id = db.Column(db.Integer, db.ForeignKey('product_batch.id'), nullable=False)
    requested_by = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    quantity = db.Column(db.Float, nullable=False)
    reason = db.Column(db.String(200), nullable=False)
    remarks = db.Column(db.Text)
    status = db.Column(db.String(20), default='Pending')  # Pending, Approved, Rejected
    reviewed_by = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    reviewed_at = db.Column(db.DateTime, nullable=True)
    review_remarks = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(ZoneInfo("Asia/Manila")))
    company_id = db.Column(db.Integer, db.ForeignKey('company.id'), nullable=False)
    
    # Relationships
    product = db.relationship('Product', backref='pending_removals')
    batch = db.relationship('ProductBatch', backref='pending_removals')
    requester = db.relationship('User', foreign_keys=[requested_by], backref='pending_removals_requested')
    reviewer = db.relationship('User', foreign_keys=[reviewed_by], backref='pending_removals_reviewed')