# Standard library imports
from urllib.parse import quote_plus

# Third-party imports
from flask import Flask, render_template
from flask_login import current_user
from flask_migrate import Migrate
from werkzeug.exceptions import HTTPException

# Local imports
from config import config
from extensions import db, login_manager, mail
from models import User, Requisition, PendingRemoval
from template_filters import format_relative_time, to_float
from routes.auth import auth
from routes.main import main
from routes.products import products
from routes.requisitions import requisitions
from routes.admin import admin
from routes.scanner import scanner
from routes.api import api
from routes.logs import logs
from routes.misc import misc
from routes.pending_removals import pending_removals
from routes.companies import companies

# Import user loader function
def load_user(user_id):
    return User.query.get(int(user_id))


def create_app(config_name='default'):
    """Application factory pattern"""
    app = Flask(__name__)
    
    # Load configuration
    app.config.from_object(config[config_name])
    
    # Initialize extensions
    db.init_app(app)
    login_manager.init_app(app)
    mail.init_app(app)
    
    # Initialize Flask-Migrate
    migrate = Migrate(app, db)
    
    # Configure login manager
    login_manager.user_loader(load_user)
    
    # Register template filters
    app.template_filter('relative_time')(format_relative_time)
    app.template_filter('to_float')(to_float)
    
    # Add custom filter for decimal formatting
    @app.template_filter('decimal_format')
    def decimal_format(value, decimal_places=2):
        """Format a number to specified decimal places (default 2)"""
        try:
            return f"{float(value):.{decimal_places}f}"
        except (ValueError, TypeError):
            return value
    
    # Add custom filter for URL encoding
    @app.template_filter('urlencode')
    def urlencode_filter(value):
        """URL encode a string for use in URLs"""
        if value is None:
            return ''
        return quote_plus(str(value))
    
    # Add context processor to provide global variables to templates
    @app.context_processor
    def inject_global_vars():
        """Provide global variables to all templates"""
        if current_user.is_authenticated:
            # Count pending requisitions for current user's company
            pending_requisition_count = Requisition.query.filter_by(
                status='Pending',
                company_id=current_user.company_id
            ).count()
            
            # Count pending removals based on user role
            if current_user.role == 'WH-Admin':
                # WH-Admin can only see their own pending removals
                pending_removal_count = PendingRemoval.query.filter_by(
                    status='Pending',
                    requested_by=current_user.id
                ).count()
            else:
                # SYS-Admin and Company-Admin can see all pending removals in their company
                pending_removal_count = PendingRemoval.query.filter_by(
                    status='Pending',
                    company_id=current_user.company_id
                ).count()
            
            return dict(
                current_user=current_user,
                pending_requisition_count=pending_requisition_count,
                pending_removal_count=pending_removal_count
            )
        return dict(current_user=current_user)
    
    # Register blueprints
    app.register_blueprint(auth)
    app.register_blueprint(main)
    app.register_blueprint(products)
    app.register_blueprint(requisitions)
    app.register_blueprint(admin)
    app.register_blueprint(scanner)
    app.register_blueprint(api)
    app.register_blueprint(logs)
    app.register_blueprint(misc)
    app.register_blueprint(pending_removals)
    app.register_blueprint(companies)
    
    # Error handlers
    @app.errorhandler(404)
    def not_found_error(error):
        # Provide default values for template variables used in base-sidebar.html
        # These are needed because the context processor isn't called for error handlers
        if current_user.is_authenticated:
            # Count pending requisitions for current user's company
            pending_requisition_count = Requisition.query.filter_by(
                status='Pending',
                company_id=current_user.company_id
            ).count()
            
            # Count pending removals based on user role
            if current_user.role == 'WH-Admin':
                # WH-Admin can only see their own pending removals
                pending_removal_count = PendingRemoval.query.filter_by(
                    status='Pending',
                    requested_by=current_user.id
                ).count()
            else:
                # SYS-Admin and Company-Admin can see all pending removals in their company
                pending_removal_count = PendingRemoval.query.filter_by(
                    status='Pending',
                    company_id=current_user.company_id
                ).count()
        else:
            # For unauthenticated users, set counts to 0
            pending_requisition_count = 0
            pending_removal_count = 0
            
        return render_template('404.html', 
                             pending_requisition_count=pending_requisition_count,
                             pending_removal_count=pending_removal_count), 404

    @app.errorhandler(500)
    def internal_error(error):
        db.session.rollback()
        # Provide default values for template variables used in base-sidebar.html
        # These are needed because the context processor isn't called for error handlers
        if current_user.is_authenticated:
            # Count pending requisitions for current user's company
            pending_requisition_count = Requisition.query.filter_by(
                status='Pending',
                company_id=current_user.company_id
            ).count()
            
            # Count pending removals based on user role
            if current_user.role == 'WH-Admin':
                # WH-Admin can only see their own pending removals
                pending_removal_count = PendingRemoval.query.filter_by(
                    status='Pending',
                    requested_by=current_user.id
                ).count()
            else:
                # SYS-Admin and Company-Admin can see all pending removals in their company
                pending_removal_count = PendingRemoval.query.filter_by(
                    status='Pending',
                    company_id=current_user.company_id
                ).count()
        else:
            # For unauthenticated users, set counts to 0
            pending_requisition_count = 0
            pending_removal_count = 0
            
        return render_template('500.html',
                             pending_requisition_count=pending_requisition_count,
                             pending_removal_count=pending_removal_count), 500
    
    @app.errorhandler(Exception)
    def handle_exception(e):
        # Pass through HTTP errors
        if isinstance(e, HTTPException):
            return e
        
        # Log the error for debugging
        app.logger.error(f'Unhandled exception: {e}', exc_info=True)
        
        # For non-HTTP exceptions, return a generic 500 error
        db.session.rollback()
        return render_template('500.html'), 500
    
    # Create tables and initialize database
    with app.app_context():
        try:
            db.create_all()
        except Exception as e:
            # If there's an error with the database, rollback and continue
            db.session.rollback()
            app.logger.warning(f"Database initialization error (may be expected during first run): {e}")
    
    return app


def inspect_table_exists(table_name):
    """Check if a table exists in the database"""
    try:
        from sqlalchemy import inspect
        inspector = inspect(db.engine)
        return table_name in inspector.get_table_names()
    except:
        return False


# Create the application instance
app = create_app()

# Import routes after app creation to avoid circular imports
# Routes are already imported above for blueprint registration

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)